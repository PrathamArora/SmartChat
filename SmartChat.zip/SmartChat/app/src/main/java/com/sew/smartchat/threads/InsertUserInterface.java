package com.sew.smartchat.threads;

public interface InsertUserInterface {
    void userInserted(boolean result);
}
