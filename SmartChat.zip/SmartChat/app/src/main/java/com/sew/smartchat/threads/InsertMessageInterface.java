package com.sew.smartchat.threads;

public interface InsertMessageInterface {
    void messageInserted(boolean result);
}
