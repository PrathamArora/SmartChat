package com.sew.smartchat.threads;

public interface InsertTopicInterface {
    void topicInserted(boolean result);
}
